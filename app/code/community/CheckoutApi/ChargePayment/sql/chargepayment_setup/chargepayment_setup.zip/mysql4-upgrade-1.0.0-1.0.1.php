<?php

/* @var $installer Mage_Core_Model_Resource_Setup */
$this->startSetup();

$this->getConnection()->addColumn(
    $this->getTable('sales/quote_payment'),
    'checkout_api_card_id','varchar(25)'
);

$this->getConnection()->addColumn(
    $this->getTable('sales/order_payment'),
    'checkout_api_card_id','varchar(25)'
);

$this->endSetup();
