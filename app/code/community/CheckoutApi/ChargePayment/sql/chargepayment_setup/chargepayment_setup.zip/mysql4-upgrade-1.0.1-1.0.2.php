<?php

/* @var $installer Mage_Core_Model_Resource_Setup */
$this->startSetup();

$this->getConnection()->addColumn(
    $this->getTable('sales/order'),
    'charge_is_captured','int(1)'
);

$this->getConnection()->addColumn(
    $this->getTable('sales/order'),
    'charge_is_voided','int(1)'
);

$this->getConnection()->addColumn(
    $this->getTable('sales/order'),
    'charge_is_refunded','int(1)'
);

$this->endSetup();