<?php

$this->startSetup();

$this->getConnection()->addColumn(
    $this->getTable('chargepayment_cards'),
    'save_card', varchar(11)
);


$this->endSetup();