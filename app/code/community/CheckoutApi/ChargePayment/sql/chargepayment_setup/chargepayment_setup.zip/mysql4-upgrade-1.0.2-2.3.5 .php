<?php

$this->startSetup();

$this->getConnection()->addColumn(
    $this->getTable('chargepayment_cards'),
    'save_card','varchar(25)'
);


$this->endSetup();